
module.exports = require('./dev')